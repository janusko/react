      import './App.css';
import UserForm from './components/Form'
import Data from './components/Data';

function App() {
  return (
    <UserForm>
        <Data />
    </UserForm>
  );
}

export default App;