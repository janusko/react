import './App.css';
import UserForm from './components/Form';

function App() {
  return (
      <UserForm />
  );
}

export default App;
