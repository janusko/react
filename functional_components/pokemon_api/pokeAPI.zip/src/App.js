import './App.css';
import Pokemon from './components/Pokemon';
import Fetch from './views/Fetch';

function App() {
  return (
    <div className="App">
        <Fetch />
        {/* <Pokemon /> */}
    </div>
  );
}

export default App;
